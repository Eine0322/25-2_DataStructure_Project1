#include "ArtistBST.h"
#include "ArtistBSTNode.h"
#include <iostream>
#include <string>
#include <algorithm>
#include <sstream>
#include <vector>

using namespace std;

// Finds and returns the node with the smallest artist name in the given subtree
ArtistBSTNode* ArtistBST::findMinNode(ArtistBSTNode* node) {
    ArtistBSTNode* current = node;                       // Start from the given node
    while (current && current->getLeft() != nullptr) {   // Traverse to the leftmost node
        current = current->getLeft();
    }
    return current;                                      // Return the smallest node
}

// Inserts a new node or song recursively based on artist name
ArtistBSTNode* ArtistBST::insertRecursive(ArtistBSTNode* node, const string& artist,
    const string& title, int time_sec) {
    if (node == nullptr) {                               // If tree is empty, create new node
        return new ArtistBSTNode(artist, title, time_sec);
    }

    if (artist < node->getArtist()) {                    // If artist name is smaller → go left
        node->setLeft(insertRecursive(node->getLeft(), artist, title, time_sec));
    }
    else if (artist > node->getArtist()) {               // If artist name is larger → go right
        node->setRight(insertRecursive(node->getRight(), artist, title, time_sec));
    }
    else {                                               // If artist already exists
        node->addSong(title, time_sec);                  // Add new song to existing artist node
    }

    return node;                                         // Return the updated node
}

// Deletes a node recursively based on artist name
ArtistBSTNode* ArtistBST::deleteRecursive(ArtistBSTNode* node, const string& artistName) {
    if (node == nullptr) {                               // Base case: node not found
        return nullptr;
    }

    if (artistName < node->getArtist()) {                // Target artist is in left subtree
        node->setLeft(deleteRecursive(node->getLeft(), artistName));
    }
    else if (artistName > node->getArtist()) {           // Target artist is in right subtree
        node->setRight(deleteRecursive(node->getRight(), artistName));
    }
    else {                                               // Artist found → delete this node
        // Case 1: only right child or no left child
        if (node->getLeft() == nullptr) {
            ArtistBSTNode* temp = node->getRight();
            delete node;
            return temp;                                 // Return the new subtree root
        }
        // Case 2: only left child or no right child
        else if (node->getRight() == nullptr) {
            ArtistBSTNode* temp = node->getLeft();
            delete node;
            return temp;
        }

        // Case 3: two children exist
        ArtistBSTNode* temp = findMinNode(node->getRight()); // Find inorder successor
        node->swapContent(temp);                             // Replace current node’s content
        node->setRight(deleteRecursive(node->getRight(), temp->getArtist())); // Delete successor
    }
    return node;                                             // Return updated subtree
}

// Performs in-order traversal (Artist, Title, Time)
void ArtistBST::inorderRecursive(ArtistBSTNode* node, ostream& os) {
    if (node == nullptr) return;                             // Base case: empty node

    inorderRecursive(node->getLeft(), os);                   // Visit left subtree

    const vector<string>& titles = node->getTitles();        // Get artist's song list
    const vector<int>& runtimes = node->getRunTimes();       // Get song runtime list

    // Print all songs of the artist
    for (size_t i = 0; i < titles.size(); ++i) {
        os << node->getArtist() << "/" << titles[i] << "/"
            << secondsToTimeStr(runtimes[i]) << "\n";
    }

    inorderRecursive(node->getRight(), os);                  // Visit right subtree
}

// Deletes all nodes in the tree recursively (used in destructor)
void ArtistBST::deleteTree(ArtistBSTNode* node) {
    if (node == nullptr) return;                             // Base case: nothing to delete
    deleteTree(node->getLeft());                             // Delete left subtree
    deleteTree(node->getRight());                            // Delete right subtree
    delete node;                                             // Delete current node
}

// Constructor: initializes an empty BST
ArtistBST::ArtistBST() : root(nullptr), parent(nullptr), target(nullptr) {
    data = "";                                               // Initialize helper string
}

// Destructor: deletes the entire BST
ArtistBST::~ArtistBST() {
    deleteTree(root);
}

// Public wrapper for insertion
void ArtistBST::insert(const string& artist, const string& title, int time_sec) {
    root = insertRecursive(root, artist, title, time_sec);   // Call recursive insertion
}

// Searches for a specific artist node by name
ArtistBSTNode* ArtistBST::search(const string& artistName) {
    ArtistBSTNode* current = root;                           // Start at root
    while (current != nullptr) {                             // Traverse until found or null
        if (artistName == current->getArtist()) {            // Exact match found
            return current;
        }
        else if (artistName < current->getArtist()) {        // If smaller, go left
            current = current->getLeft();
        }
        else {                                               // If larger, go right
            current = current->getRight();
        }
    }
    return nullptr;                                          // Artist not found
}

// Prints the BST in in-order format (uses clog output)
void ArtistBST::print() {
    if (root == nullptr) {                                   // Case: empty BST
        clog << "========ERROR========" << endl;
        clog << "600" << endl;
        clog << "=====================" << endl;
        return;
    }

    clog << "========PRINT========" << endl;
    clog << "ArtistBST" << endl;
    inorderRecursive(root, clog);                            // Perform in-order traversal
    clog << "=====================" << endl;
}

// Deletes an artist and all associated songs from the BST
void ArtistBST::delete_node(const string& artistName) {
    root = deleteRecursive(root, artistName);                // Update root after deletion
}