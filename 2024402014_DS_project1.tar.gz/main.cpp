#include "Manager.h"

using namespace std;

int main() {
    // Create an instance of the Manager class
    // This will handle loading commands, processing them, and managing playlists
    Manager manager;

    // Run the manager with the provided command file
    // The command file is passed as an argument
    manager.run("command.txt");

    return 0;  // Exit the program with success
}