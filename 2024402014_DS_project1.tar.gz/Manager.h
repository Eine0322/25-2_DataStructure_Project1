#pragma once
#include "MusicQueue.h"
#include "TitleBST.h"
#include "ArtistBST.h"
#include "PlayList.h"
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <tuple>
#include <algorithm>

using namespace std;

// Converts time string "M:SS" into total seconds (integer)
inline int timeToSeconds(const string& timeStr) {
    size_t pos = timeStr.find(':');                   // Find the position of ':'
    if (pos == string::npos) return 0;                // If format is invalid, return 0
    int m = 0, s = 0;
    try {
        m = stoi(timeStr.substr(0, pos));             // Extract minutes
        s = stoi(timeStr.substr(pos + 1));            // Extract seconds
    }
    catch (...) { return 0; }                         // Handle invalid string (non-numeric)
    return m * 60 + s;                                // Convert to total seconds
}

class Manager {
private:
    MusicQueue q;                                     // Queue structure for temporary song storage
    ArtistBST  ab;                                    // Binary Search Tree for artist-based organization
    TitleBST   tb;                                    // Binary Search Tree for title-based organization
    PlayList   pl;                                    // Circular linked list for playlist

    ifstream fcmd;                                    // Input stream for reading command.txt
    ofstream flog;                                    // Output stream for writing log.txt

    // ===== Helper functions (formatting & parsing) =====
    // Prints command header line like "========LOAD========"
    void printHeader(const string& tag) {
        flog << "========" << tag << "========\n";
    }

    // Prints footer line "===================="
    void printFooter() {
        flog << "====================\n";
    }

    // Prints formatted error block
    void printError(int code) {
        flog << "========ERROR========\n";
        flog << code << "\n";
        printFooter();
    }

    // Removes leading/trailing whitespace from a string
    static string trim(const string& s) {
        size_t b = s.find_first_not_of(" \t\r\n");
        size_t e = s.find_last_not_of(" \t\r\n");
        if (b == string::npos) return "";
        return s.substr(b, e - b + 1);
    }

    // Parses a key in "Artist|Title" format into (artist, title)
    static bool parseSongKey(const string& key, string& artist, string& title) {
        size_t bar = key.find('|');                   // Find separator '|'
        if (bar == string::npos) return false;        // Return false if format invalid
        artist = trim(key.substr(0, bar));            // Extract artist name
        title = trim(key.substr(bar + 1));            // Extract title
        return !(artist.empty() || title.empty());    // Return true only if both are non-empty
    }

    // Checks if playlist already contains a specific song (Artist/Title)
    bool playlistContains(const string& artist, const string& title) {
        string dump = pl.print();                     // Retrieve playlist as formatted string
        string needle = artist + "/" + title + "/";   // Construct search target
        return dump.find(needle) != string::npos;     // Return true if found
    }

    // Extracts only the playlist body (without header/footer) for MAKEPL output
    string playlistBody() {
        string dump = pl.print();                     // Get full formatted playlist
        stringstream ss(dump);
        string line, out;
        int stage = 0;

        // Skip header/footer, keep only main body lines
        while (getline(ss, line)) {
            if (line.rfind("========PRINT========", 0) == 0) { stage = 1; continue; }
            if (stage == 1 && line == "PlayList") { stage = 2; continue; }
            if (stage >= 2) {
                if (line.rfind("====================", 0) == 0) break;
                out += line + "\n";
            }
        }
        return out;
    }

    // Searches a song in ArtistBST by (artist, title), returns time_sec if found
    bool findSongInArtistBST(const string& artist, const string& title, int& time_sec) {
        ArtistBSTNode* aNode = ab.search(artist);
        if (!aNode) return false;                     // Artist not found

        const auto& titles = aNode->getTitles();      // Retrieve all song titles under this artist
        const auto& rts = aNode->getRunTimes();       // Retrieve corresponding runtimes

        for (size_t i = 0; i < titles.size(); ++i) {
            if (titles[i] == title) {                 // If song matches
                time_sec = rts[i];
                return true;
            }
        }
        return false;                                 // Song not found under artist
    }

    // Searches a song in TitleBST by (title, artist), returns time_sec if found
    bool findSongInTitleBST(const string& title, const string& artist, int& time_sec) {
        TitleBSTNode* tNode = tb.search(title);
        if (!tNode) return false;                     // Title not found

        const auto& arts = tNode->getArtists();       // Retrieve all artists under this title
        const auto& rts = tNode->getRunTimes();       // Retrieve corresponding runtimes

        for (size_t i = 0; i < arts.size(); ++i) {
            if (arts[i] == artist) {                  // If artist matches
                time_sec = rts[i];
                return true;
            }
        }
        return false;                                 // Song not found under title
    }

public:
    // Constructor: opens log file for writing
    Manager();

    // Destructor: closes file streams and releases memory
    ~Manager();

    // Executes all commands from command.txt sequentially
    void run(const char* command);

    // ===== Command functions (project core features) =====
    void LOAD();                                      // Loads songs into MusicQueue
    void ADD(const std::string& args);                // Adds new song to queue
    void QPOP();                                      // Pops one song from queue into BSTs
    void SEARCH(const std::string& args);             // Searches for a song/artist/title
    void MAKEPL(const std::string& args);             // Builds playlist from BST data
    void PRINT(const std::string& args);              // Prints structure contents
    void DELETE(const std::string& args);             // Deletes songs from structures
    void EXIT();                                      // Frees memory and terminates program
};