#pragma once
#include <string>
#include <sstream>

class MusicQueueNode {
private:
    std::string artist;       // Stores the artist name
    std::string title;        // Stores the song title
    std::string run_time;     // Stores the running time of the song (format: mm:ss)
    MusicQueueNode* next;     // Pointer to the next node in the queue
    MusicQueueNode* prev;     // Pointer to the previous node in the queue

public:
    // Default constructor: initializes next and prev pointers as null
    MusicQueueNode() : next(nullptr), prev(nullptr) {}

    // Parameterized constructor: initializes node with artist, title, and run time
    MusicQueueNode(const std::string& art, const std::string& tit, const std::string& time)
        : artist(art), title(tit), run_time(time), next(nullptr), prev(nullptr) {
    }

    // Destructor: releases node resources (no dynamic memory here)
    ~MusicQueueNode() {}

    // ===== Getter methods =====
    // Returns the artist name
    const std::string& getArtist() const { return artist; }

    // Returns the song title
    const std::string& getTitle()  const { return title; }

    // Returns the running time
    const std::string& getRunTime() const { return run_time; }

    // Returns a pointer to the next node
    MusicQueueNode* getNext() const { return next; }

    // Returns a pointer to the previous node
    MusicQueueNode* getPrev() const { return prev; }

    // ===== Setter methods =====
    // Sets the pointer to the next node
    void setNext(MusicQueueNode* n) { next = n; }

    // Sets the pointer to the previous node
    void setPrev(MusicQueueNode* p) { prev = p; }

    // Unused placeholder function for future expansion
    void insert() {}

    // Unused placeholder function for existence check (currently returns false)
    bool exist() { return false; }
};
