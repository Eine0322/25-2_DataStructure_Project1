#include "TitleBST.h"
#include "TitleBSTNode.h"
#include "ArtistBST.h" // for secondsToTimeStr()
#include <iostream>
#include <string>
#include <algorithm>
#include <sstream>
#include <vector>

using namespace std;

// Finds and returns the node with the smallest title in the given subtree
TitleBSTNode* TitleBST::findMinNode(TitleBSTNode* node) {
    TitleBSTNode* current = node;                       // Start at the given node
    while (current && current->getLeft() != nullptr) {  // Traverse to the leftmost node
        current = current->getLeft();
    }
    return current;                                     // Return the minimum node
}

// Inserts a new title node or adds an artist if the title already exists (recursive)
TitleBSTNode* TitleBST::insertRecursive(TitleBSTNode* node, const string& artist,
    const string& title, int time_sec) {
    if (node == nullptr) {                              // Case: empty tree → create new node
        return new TitleBSTNode(artist, title, time_sec);
    }

    if (title < node->getTitle()) {                     // Case: title is smaller → go left
        node->setLeft(insertRecursive(node->getLeft(), artist, title, time_sec));
    }
    else if (title > node->getTitle()) {                // Case: title is larger → go right
        node->setRight(insertRecursive(node->getRight(), artist, title, time_sec));
    }
    else {                                              // Case: title already exists
        node->addArtist(artist, time_sec);              // Add new artist to this title node
    }

    return node;                                        // Return updated node
}

// Deletes a node recursively based on title name
TitleBSTNode* TitleBST::deleteRecursive(TitleBSTNode* node, const string& titleName) {
    if (node == nullptr) return nullptr;                // Base case: title not found

    if (titleName < node->getTitle()) {                 // Target title is in left subtree
        node->setLeft(deleteRecursive(node->getLeft(), titleName));
    }
    else if (titleName > node->getTitle()) {            // Target title is in right subtree
        node->setRight(deleteRecursive(node->getRight(), titleName));
    }
    else {                                              // Title found → delete this node
        // Case 1: node has no left child
        if (node->getLeft() == nullptr) {
            TitleBSTNode* temp = node->getRight();      // Replace with right child
            delete node;
            return temp;
        }
        // Case 2: node has no right child
        else if (node->getRight() == nullptr) {
            TitleBSTNode* temp = node->getLeft();       // Replace with left child
            delete node;
            return temp;
        }

        // Case 3: node has two children → replace with inorder successor
        TitleBSTNode* temp = findMinNode(node->getRight()); // Find smallest node in right subtree
        node->swapContent(temp);                           // Copy successor data
        node->setRight(deleteRecursive(node->getRight(), temp->getTitle())); // Delete successor
    }
    return node;                                           // Return updated subtree
}

// Performs in-order traversal (Title / Artist / Time) and prints to the output stream
void TitleBST::inorderRecursive(TitleBSTNode* node, ostream& os) {
    if (node == nullptr) return;                           // Base case: end of recursion

    inorderRecursive(node->getLeft(), os);                 // Traverse left subtree first

    const vector<string>& artists = node->getArtists();    // Get list of artists for this title
    const vector<int>& runtimes = node->getRunTimes();     // Get list of runtimes (seconds)

    // Print all artists who have this song title
    for (size_t i = 0; i < artists.size(); ++i) {
        os << artists[i] << "/" << node->getTitle() << "/"
            << secondsToTimeStr(runtimes[i]) << "\n";       // Format: Artist/Title/Time
    }

    inorderRecursive(node->getRight(), os);                // Traverse right subtree next
}

// Deletes all nodes recursively (used in destructor)
void TitleBST::deleteTree(TitleBSTNode* node) {
    if (node == nullptr) return;                           // Base case: empty node
    deleteTree(node->getLeft());                           // Delete left subtree
    deleteTree(node->getRight());                          // Delete right subtree
    delete node;                                           // Delete current node
}

// Constructor: initializes an empty BST
TitleBST::TitleBST() : root(nullptr), parent(nullptr), target(nullptr) {
    data = "";                                             // Initialize helper string
}

// Destructor: deletes all nodes to free memory
TitleBST::~TitleBST() {
    deleteTree(root);
}

// Wrapper for inserting a new song into the BST
void TitleBST::insert(const string& artist, const string& title, int time_sec) {
    root = insertRecursive(root, artist, title, time_sec);
}

// Searches for a node by title name and returns its pointer if found
TitleBSTNode* TitleBST::search(const string& titleName) {
    TitleBSTNode* current = root;                          // Start from root
    while (current != nullptr) {
        if (titleName == current->getTitle()) return current;     // Match found
        else if (titleName < current->getTitle()) current = current->getLeft();  // Go left
        else current = current->getRight();                           // Go right
    }
    return nullptr;                                        // Title not found
}

// Prints the BST contents in-order (matches project specification)
void TitleBST::print() {
    if (root == nullptr) {                                 // If tree is empty, print error
        clog << "========ERROR========" << endl;
        clog << "600" << endl;
        clog << "=====================" << endl;
        return;
    }

    clog << "========PRINT========" << endl;               // Print header
    clog << "TitleBST" << endl;
    inorderRecursive(root, clog);                          // Print all data via in-order traversal
    clog << "=====================" << endl;               // Print footer
}

// Deletes a specific title node from the BST
void TitleBST::delete_node(const string& titleName) {
    root = deleteRecursive(root, titleName);               // Call recursive deletion
}