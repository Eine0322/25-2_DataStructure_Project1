#pragma once
#include "ArtistBSTNode.h"
#include <string>
#include <iostream>
#include <sstream>

// Converts seconds into a formatted string "M:SS"
inline std::string secondsToTimeStr(int totalSeconds) {
    int minutes = totalSeconds / 60;                       // Calculate minutes
    int seconds = totalSeconds % 60;                       // Calculate remaining seconds
    std::stringstream ss;
    ss << minutes << ":" << (seconds < 10 ? "0" : "") << seconds;   // Format as "M:SS"
    return ss.str();                                        // Return formatted string
}

// Binary Search Tree for storing artist information
class ArtistBST {
private:
    ArtistBSTNode* root;       // Pointer to the root node of the tree
    ArtistBSTNode* parent;     // Temporary pointer used during traversal (for deletion)
    std::string data;          // Temporary string used for parsing or storing intermediate data
    ArtistBSTNode* target;     // Pointer used to store the target node during searches or deletions

    // Private helper functions
    // Recursively inserts an artist node into the BST
    ArtistBSTNode* insertRecursive(ArtistBSTNode* node, const std::string& artist,
        const std::string& title, int time_sec);

    // Recursively deletes an artist node from the BST
    ArtistBSTNode* deleteRecursive(ArtistBSTNode* node, const std::string& artistName);

    // Recursively deletes the entire tree (used in destructor)
    void deleteTree(ArtistBSTNode* node);

    // Finds and returns the node with the smallest artist name in the given subtree
    ArtistBSTNode* findMinNode(ArtistBSTNode* node);

    // Performs in-order traversal of the tree and outputs node data
    void inorderRecursive(ArtistBSTNode* node, std::ostream& os);

public:
    // Constructor: initializes an empty BST
    ArtistBST();

    // Destructor: releases all allocated memory by deleting all nodes
    ~ArtistBST();

    // Public function to insert an artist into the BST
    void insert(const std::string& artist, const std::string& title, int time_sec);

    // Searches for an artist by name and returns the corresponding node
    ArtistBSTNode* search(const std::string& artistName);

    // Prints the entire tree in in-order traversal format (Artist/Title/Time)
    void print(); // Uses clog by default for output

    // Deletes an artist node from the BST
    void delete_node(const std::string& artistName);
};
