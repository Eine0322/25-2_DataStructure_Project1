#include "MusicQueue.h"
#include "MusicQueueNode.h" 
#include <iostream>
#include <string>
#include <cstdlib> 

#define MAX_SIZE 100   // Defines the maximum number of songs allowed in the queue

// Constructor: initializes an empty queue with size set to 0
MusicQueue::MusicQueue() : head(nullptr), rear(nullptr), size(0) {}

// Destructor: deletes all nodes in the queue to free memory
MusicQueue::~MusicQueue() {
    while (!empty()) {                        // Continue until the queue becomes empty
        MusicQueueNode* temp = head;          // Store the current front node
        head = temp->getNext();               // Move head to the next node
        delete temp;                          // Delete the old head node
    }
    rear = nullptr;                           // Set rear pointer to null
    size = 0;                                 // Reset size counter
}

// Checks if the queue is empty
bool MusicQueue::empty() const { return head == nullptr; }

// Checks if the queue has reached its maximum capacity (100)
bool MusicQueue::isFull() const { return size >= MAX_SIZE; }

// Returns true if the queue has any existing elements
bool MusicQueue::exist() const { return size > 0; }

// Adds a new node to the rear (end) of the queue
void MusicQueue::push(MusicQueueNode* newNode) {
    if (!newNode) return;                     // If the new node is null, do nothing

    newNode->setNext(nullptr);                // Initialize next pointer to null
    newNode->setPrev(nullptr);                // Initialize prev pointer to null

    if (empty()) {                            // Case: queue is currently empty
        head = rear = newNode;                // The new node becomes both head and rear
    }
    else {                                    // Case: queue has existing nodes
        rear->setNext(newNode);               // Link the current rear to the new node
        newNode->setPrev(rear);               // Set the new node's previous pointer to the current rear
        rear = newNode;                       // Update rear pointer to the new node
    }
    ++size;                                   // Increase queue size count
}

// Checks if a song with the same artist and title already exists in the queue
bool MusicQueue::exist(const std::string& artist, const std::string& title) const {
    for (MusicQueueNode* cur = head; cur; cur = cur->getNext()) { // Traverse the queue
        if (cur->getArtist() == artist && cur->getTitle() == title) // Match both artist and title
            return true;                                           // Found a duplicate song
    }
    return false;                                                  // No matching song found
}

// Removes and returns the front node from the queue (FIFO order)
MusicQueueNode* MusicQueue::pop() {
    if (empty()) return nullptr;             // If the queue is empty, return null

    MusicQueueNode* temp = head;             // Store current front node
    head = temp->getNext();                  // Move head pointer to the next node

    if (head) head->setPrev(nullptr);        // If there’s a next node, clear its previous pointer
    else      rear = nullptr;                // If queue becomes empty, reset rear pointer

    temp->setNext(nullptr);                  // Disconnect the popped node completely
    temp->setPrev(nullptr);
    --size;                                  // Decrease the queue size
    return temp;                             // Return the removed node
}

// Returns the front node without removing it
MusicQueueNode* MusicQueue::front() const { return head; }
