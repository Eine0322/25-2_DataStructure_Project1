#pragma once
#include "MusicQueueNode.h"
#include <vector>
#include <string>
#include <sstream>

class ArtistBSTNode {
private:
    std::string artist;                   // Stores the artist's name
    std::vector<std::string> title;       // Stores all song titles of the artist
    std::string run_time;                 // Stores the formatted running time (mm:ss)
    std::vector<int> rt;                  // Stores each song's running time in seconds
    int count;                            // Number of songs for this artist
    ArtistBSTNode* left;                  // Pointer to the left child in the BST
    ArtistBSTNode* right;                 // Pointer to the right child in the BST

public:
    // Default constructor: initializes an empty node
    ArtistBSTNode() : count(0), left(nullptr), right(nullptr) {}

    // Parameterized constructor: initializes a node with given artist, title, and running time
    ArtistBSTNode(const std::string& art, const std::string& tit, int time_sec)
        : artist(art), count(1), left(nullptr), right(nullptr) {
        title.push_back(tit);                 // Add song title to the list
        rt.push_back(time_sec);               // Add run time in seconds
        int m = time_sec / 60, s = time_sec % 60;   // Convert seconds into minutes and seconds
        std::stringstream ss;
        ss << m << ":" << (s < 10 ? "0" : "") << s; // Format as "m:ss"
        run_time = ss.str();                  // Save formatted string
    }

    // ===== Getter methods =====
    std::string getArtist() const { return artist; }                            // Returns artist name
    ArtistBSTNode* getLeft() const { return left; }                             // Returns left child pointer
    ArtistBSTNode* getRight() const { return right; }                           // Returns right child pointer
    const std::vector<std::string>& getTitles() const { return title; }         // Returns vector of song titles
    const std::vector<int>& getRunTimes() const { return rt; }                  // Returns vector of run times (sec)
    std::string getRunTime() const { return run_time; }                         // Returns formatted runtime

    // ===== Setter methods =====
    void setLeft(ArtistBSTNode* n) { left = n; }                                // Sets left child pointer
    void setRight(ArtistBSTNode* n) { right = n; }                              // Sets right child pointer

    // Adds a new song to the artist node
    void addSong(const std::string& tit, int time_sec) {
        title.push_back(tit);               // Add the song title to list
        rt.push_back(time_sec);             // Add the runtime in seconds
        count++;                            // Increment song count
        int m = time_sec / 60, s = time_sec % 60;   // Convert to minute/second
        std::stringstream ss;
        ss << m << ":" << (s < 10 ? "0" : "") << s; // Format time as string
        run_time = ss.str();                // Update formatted runtime string
    }

    // Swaps all content between this node and another node
    void swapContent(ArtistBSTNode* o) {
        artist = o->artist;
        title = o->title;
        rt = o->rt;
        run_time = o->run_time;
        count = o->count;
    }

    // Removes a song from the artist’s list by title
    bool removeSongByTitle(const std::string& tit) {
        for (size_t i = 0; i < title.size(); ++i) {   // Iterate through song list
            if (title[i] == tit) {                    // Match found
                title.erase(title.begin() + i);       // Remove the title
                rt.erase(rt.begin() + i);             // Remove the corresponding runtime
                count--;                              // Decrease song count
                return true;                          // Successfully removed
            }
        }
        return false;                                 // Title not found
    }

    // Placeholder function for potential future setup logic
    void set() {}

    // Placeholder function for potential future search logic
    void search() {}
};
