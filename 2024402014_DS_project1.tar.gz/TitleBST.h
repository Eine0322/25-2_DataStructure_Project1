#pragma once
#include "TitleBSTNode.h"
#include <string>
#include <iostream>
#include <sstream>

class TitleBST {
private:
    TitleBSTNode* root;        // Pointer to the root node of the BST
    TitleBSTNode* parent;      // Temporary pointer used for traversal (mainly for deletion)
    std::string data;          // Temporary string storage used during operations
    TitleBSTNode* target;      // Pointer to the target node during search or deletion

    // Recursively inserts a new title node or adds an artist if the title already exists
    TitleBSTNode* insertRecursive(TitleBSTNode* node, const std::string& artist,
        const std::string& title, int time_sec);

    // Recursively deletes a node that matches a given title
    TitleBSTNode* deleteRecursive(TitleBSTNode* node, const std::string& titleName);

    // Recursively deletes the entire tree (used in destructor)
    void deleteTree(TitleBSTNode* node);

    // Finds and returns the node with the smallest title (used in deletion)
    TitleBSTNode* findMinNode(TitleBSTNode* node);

    // Traverses the BST in in-order sequence and prints node data
    void inorderRecursive(TitleBSTNode* node, std::ostream& os);

public:
    // Constructor: initializes an empty TitleBST
    TitleBST();

    // Destructor: releases all allocated memory by deleting all nodes
    ~TitleBST();

    // Inserts a title and its artist information into the BST
    void insert(const std::string& artist, const std::string& title, int time_sec);

    // Searches for a specific title and returns the node pointer if found
    TitleBSTNode* search(const std::string& titleName);

    // Prints the BST contents in sorted order using in-order traversal
    void print();

    // Deletes the node corresponding to a specific title from the BST
    void delete_node(const std::string& titleName);
};