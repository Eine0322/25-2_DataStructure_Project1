#pragma once
#include "MusicQueueNode.h"
#include <string>

class MusicQueue {
private:
    MusicQueueNode* head;    // Pointer to the first node (front) of the queue
    MusicQueueNode* rear;    // Pointer to the last node (rear) of the queue
    int size = 0;            // Tracks the number of nodes currently in the queue

public:
    // Constructor: initializes an empty queue
    MusicQueue();

    // Destructor: releases all allocated nodes to prevent memory leaks
    ~MusicQueue();

    // Checks if the queue is empty
    bool empty() const;

    // Checks if the queue is full (maximum capacity = 100)
    bool isFull() const;

    // Checks if the queue currently holds any data (true if not empty)
    bool exist() const;

    // Adds a new node to the rear of the queue (caller must ensure queue is not full)
    void push(MusicQueueNode* newNode);

    // Checks if a specific song (artist + title) already exists in the queue
    bool exist(const std::string& artist, const std::string& title) const;

    // Removes and returns the node at the front of the queue (FIFO)
    MusicQueueNode* pop();

    // Returns a pointer to the front node without removing it
    MusicQueueNode* front() const;
};
