#pragma once
#include "PlayListNode.h"
#include <string>
#include <iostream>
#include <sstream>

class PlayList {
private:
    PlayListNode* head;     // Pointer to the first node in the circular linked list
    PlayListNode* cursor;   // Pointer to the current song node (used for navigation)
    int count;              // Total number of songs in the playlist
    int time;               // Total runtime of all songs (in seconds)
    std::string data;       // Temporary string used for formatting or internal operations

public:
    // Constructor: initializes an empty playlist
    PlayList();

    // Destructor: releases all allocated nodes and resets the list
    ~PlayList();

    // Inserts a new song node with given artist, title, and running time
    void insert_node(const std::string& artist, const std::string& title, int time_sec);

    // Deletes a song by title (removes all songs with this title if multiple exist)
    void delete_node(const std::string& title);

    // Deletes a specific song by artist and title (overloaded version)
    bool delete_node(const std::string& artist, const std::string& title);

    // Checks if the playlist is empty (no songs)
    bool empty();

    // Checks if the playlist is full (maximum 10 songs allowed)
    bool full();

    // Returns true if the playlist has at least one song
    bool exist();

    // Prints the playlist contents in formatted string (Artist/Title/Time)
    std::string print();

    // Returns total runtime of the playlist in seconds
    int run_time();
};