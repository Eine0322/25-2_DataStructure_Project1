#include "Manager.h"
#include "MusicQueueNode.h"
#include "ArtistBSTNode.h"
#include "TitleBSTNode.h"
#include "PlayListNode.h"
#include "ArtistBST.h"   // secondsToTimeStr()
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

// Constructor: opens log file in append mode
Manager::Manager() {
    flog.open("log.txt", ios::app);                   // Open for writing log outputs
    if (!flog.is_open()) {                            // Check for open failure
        cerr << "Failed to open log.txt\n";
    }
}

// Destructor: closes all file streams
Manager::~Manager() {
    if (fcmd.is_open()) fcmd.close();                 // Close command file if open
    if (flog.is_open()) flog.close();                 // Close log file if open
}

// Main controller function: executes commands from file sequentially
void Manager::run(const char* command) {
    fcmd.open(command);                               // Open command.txt file
    if (!fcmd.is_open()) {                            // File open failure
        printError(100);
        return;
    }

    string line;
    while (getline(fcmd, line)) {                     // Read commands line by line
        if (line.empty()) continue;                   // Skip blank lines
        string cmd, args;

        stringstream ss(line);
        ss >> cmd;                                    // Extract command keyword
        if (line.size() > cmd.size()) {               // Extract arguments
            args = line.substr(cmd.size());
            args = trim(args);
        }

        // Command dispatcher
        if (cmd == "LOAD")   LOAD();
        else if (cmd == "ADD")    ADD(args);
        else if (cmd == "QPOP")   QPOP();
        else if (cmd == "SEARCH") SEARCH(args);
        else if (cmd == "MAKEPL") MAKEPL(args);
        else if (cmd == "PRINT")  PRINT(args);
        else if (cmd == "DELETE") DELETE(args);
        else if (cmd == "EXIT") { EXIT(); return; }
        else printError(1000);                        // Unknown command
    }
    EXIT();                                           // Auto exit after reading file
}

/* ==========================
   LOAD: Reads Music_List.txt and populates MusicQueue
   ========================== */
void Manager::LOAD() {
    if (!q.empty()) { printError(100); return; }      // Prevent reloading if queue already filled

    ifstream in("Music_List.txt");                    // Open music list file
    if (!in.is_open()) { printError(100); return; }

    vector<tuple<string, string, string>> loaded;     // Temporary storage for successful entries
    string line;

    while (getline(in, line)) {                       // Read each line
        if (trim(line).empty()) continue;             // Skip empty lines
        stringstream ss(line);
        string artist, title, runtime;

        if (getline(ss, artist, '|') &&
            getline(ss, title, '|') &&
            getline(ss, runtime)) {                   // Split line by '|'

            artist = trim(artist);
            title = trim(title);
            runtime = trim(runtime);

            if (q.isFull() || q.exist(artist, title)) { printError(100); return; }

            auto* node = new MusicQueueNode(artist, title, runtime);
            q.push(node);                             // Push into queue
            loaded.emplace_back(artist, title, runtime);
        }
    }
    in.close();

    printHeader("LOAD");                              // Print log
    for (auto& t : loaded)
        flog << get<0>(t) << "/" << get<1>(t) << "/" << get<2>(t) << "\n";
    printFooter();
}

/* ==========================
   ADD: Adds a single song to the queue
   ========================== */
void Manager::ADD(const string& args) {
    stringstream ss(args);
    string artist, title, runtime;

    if (!(getline(ss, artist, '|') && getline(ss, title, '|') && getline(ss, runtime))) {
        printError(200); return;
    }
    artist = trim(artist);
    title = trim(title);
    runtime = trim(runtime);

    if (artist.empty() || title.empty() || runtime.empty()) { printError(200); return; }
    if (q.isFull() || q.exist(artist, title)) { printError(200); return; }

    auto* node = new MusicQueueNode(artist, title, runtime);
    q.push(node);

    printHeader("ADD");
    flog << artist << "/" << title << "/" << runtime << "\n";
    printFooter();
}

/* ==========================
   QPOP: Transfers all songs from queue to BSTs
   ========================== */
void Manager::QPOP() {
    if (q.empty()) { printError(300); return; }

    while (!q.empty()) {
        MusicQueueNode* p = q.pop();
        if (!p) break;

        string artist = p->getArtist();
        string title = p->getTitle();
        string rtime = p->getRunTime();
        int tsec = timeToSeconds(rtime);

        ab.insert(artist, title, tsec);               // Insert into ArtistBST
        tb.insert(artist, title, tsec);               // Insert into TitleBST

        delete p;                                     // Free node memory
    }

    printHeader("QPOP");
    flog << "Success\n";
    printFooter();
}

/* ==========================
   SEARCH: Finds specific artist, title, or song
   ========================== */
void Manager::SEARCH(const string& args) {
    stringstream ss(args);
    string type; ss >> type;
    if (type.empty()) { printError(400); return; }

    string key = args.substr(type.size());
    key = trim(key);
    if (key.empty()) { printError(400); return; }

    if (type == "ARTIST") {
        ArtistBSTNode* a = ab.search(key);
        if (!a) { printError(400); return; }

        printHeader("SEARCH");
        const auto& titles = a->getTitles();
        const auto& rts = a->getRunTimes();
        for (size_t i = 0; i < titles.size(); ++i)
            flog << key << "/" << titles[i] << "/" << secondsToTimeStr(rts[i]) << "\n";
        printFooter();
    }
    else if (type == "TITLE") {
        TitleBSTNode* t = tb.search(key);
        if (!t) { printError(400); return; }

        printHeader("SEARCH");
        const auto& arts = t->getArtists();
        const auto& rts = t->getRunTimes();
        for (size_t i = 0; i < arts.size(); ++i)
            flog << arts[i] << "/" << key << "/" << secondsToTimeStr(rts[i]) << "\n";
        printFooter();
    }
    else if (type == "SONG") {
        string artist, title;
        if (!parseSongKey(key, artist, title)) { printError(400); return; }

        int tsec = 0;
        bool ok = findSongInArtistBST(artist, title, tsec)
            || findSongInTitleBST(title, artist, tsec);
        if (!ok) { printError(400); return; }

        printHeader("SEARCH");
        flog << artist << "/" << title << "/" << secondsToTimeStr(tsec) << "\n";
        printFooter();
    }
    else printError(400);
}

/* ==========================
   MAKEPL: Builds playlist from BST data
   ========================== */
void Manager::MAKEPL(const string& args) {
    stringstream ss(args);
    string type; ss >> type;
    if (type.empty()) { printError(500); return; }

    string key = args.substr(type.size());
    key = trim(key);
    if (key.empty()) { printError(500); return; }

    vector<tuple<string, string, int>> songs;

    if (type == "ARTIST") {
        ArtistBSTNode* a = ab.search(key);
        if (!a) { printError(500); return; }

        const auto& titles = a->getTitles();
        const auto& rts = a->getRunTimes();

        for (size_t i = 0; i < titles.size(); ++i) {
            if (playlistContains(key, titles[i])) { printError(500); return; }
            songs.emplace_back(key, titles[i], rts[i]);
        }
    }
    else if (type == "TITLE") {
        TitleBSTNode* t = tb.search(key);
        if (!t) { printError(500); return; }

        const auto& arts = t->getArtists();
        const auto& rts = t->getRunTimes();
        for (size_t i = 0; i < arts.size(); ++i) {
            if (playlistContains(arts[i], key)) { printError(500); return; }
            songs.emplace_back(arts[i], key, rts[i]);
        }
    }
    else if (type == "SONG") {
        string artist, title;
        if (!parseSongKey(key, artist, title)) { printError(500); return; }
        int tsec = 0;
        bool ok = findSongInArtistBST(artist, title, tsec)
            || findSongInTitleBST(title, artist, tsec);
        if (!ok) { printError(500); return; }
        if (pl.full() || playlistContains(artist, title)) { printError(500); return; }
        songs.emplace_back(artist, title, tsec);
    }
    else { printError(500); return; }

    // Transaction handling: rollback if over capacity
    vector<pair<string, string>> added;
    for (const auto& s : songs) {
        if (pl.full()) {                            // Rollback if playlist exceeds 10
            for (auto it = added.rbegin(); it != added.rend(); ++it)
                pl.delete_node(it->first, it->second);
            printError(500);
            return;
        }
        const string& art = get<0>(s);
        const string& tit = get<1>(s);
        int tsec = get<2>(s);

        pl.insert_node(art, tit, tsec);
        added.emplace_back(art, tit);
    }

    printHeader("MAKEPL");
    flog << playlistBody();
    printFooter();
}

/* ==========================
   PRINT: Outputs content of BST or Playlist
   ========================== */
void Manager::PRINT(const string& args) {
    string type = trim(args);
    if (type.empty()) { printError(600); return; }

    if (type == "LIST" || type == "PL") {
        flog << pl.print();                          // Print playlist directly
        return;
    }
    else if (type == "ARTIST") {
        streambuf* old = clog.rdbuf(flog.rdbuf());   // Redirect clog output to flog
        ab.print();
        clog.rdbuf(old);
    }
    else if (type == "TITLE") {
        streambuf* old = clog.rdbuf(flog.rdbuf());
        tb.print();
        clog.rdbuf(old);
    }
    else printError(600);
}

/* ==========================
   DELETE: Removes specific artist, title, or song
   ========================== */
void Manager::DELETE(const string& args) {
    stringstream ss(args);
    string type; ss >> type;
    if (type.empty()) { printError(700); return; }

    string key = args.substr(type.size());
    key = trim(key);
    if (key.empty()) { printError(700); return; }

    // Delete from playlist
    if (type == "LIST" || type == "PL") {
        string artist, title;
        if (!parseSongKey(key, artist, title)) { printError(700); return; }
        if (!pl.exist()) { printError(700); return; }
        pl.delete_node(artist, title);
        printHeader("DELETE");
        flog << "Success\n";
        printFooter();
        return;
    }

    // Delete artist and all songs
    else if (type == "ARTIST") {
        ArtistBSTNode* aNode = ab.search(key);
        if (!aNode) { printError(700); return; }

        const auto& titles = aNode->getTitles();
        for (const auto& t : titles) {
            TitleBSTNode* tNode = tb.search(t);
            if (tNode) tNode->removeArtist(key);
            pl.delete_node(key, t);
        }
        ab.delete_node(key);
        printHeader("DELETE");
        flog << "Success\n";
        printFooter();
        return;
    }

    // Delete title and all associated artists
    else if (type == "TITLE") {
        TitleBSTNode* tNode = tb.search(key);
        if (!tNode) { printError(700); return; }

        const auto& artists = tNode->getArtists();
        for (const auto& art : artists) {
            ArtistBSTNode* aNode = ab.search(art);
            if (aNode) aNode->removeSongByTitle(key);
            pl.delete_node(art, key);
        }
        tb.delete_node(key);

        printHeader("DELETE");
        flog << "Success\n";
        printFooter();
        return;
    }

    // Delete a single song
    else if (type == "SONG") {
        string artist, title;
        if (!parseSongKey(key, artist, title)) { printError(700); return; }
        ArtistBSTNode* aNode = ab.search(artist);
        if (aNode) aNode->removeSongByTitle(title);
        TitleBSTNode* tNode = tb.search(title);
        if (tNode) tNode->removeArtist(artist);
        pl.delete_node(artist, title);
        printHeader("DELETE");
        flog << "Success\n";
        printFooter();
        return;
    }

    else printError(700);
}

/* ==========================
   EXIT: Prints success message and closes
   ========================== */
void Manager::EXIT() {
    printHeader("EXIT");
    flog << "Success\n";
    printFooter();
}