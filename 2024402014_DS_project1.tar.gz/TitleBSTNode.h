#pragma once
#include "MusicQueueNode.h"
#include <vector>
#include <string>
#include <sstream>

class TitleBSTNode {
private:
    std::string title;                     // Stores the song title
    std::vector<std::string> artist;       // Stores all artists who have this title
    std::string run_time;                  // Formatted running time string (mm:ss)
    std::vector<int> rt;                   // Stores each artist’s version run time in seconds
    int count;                             // Number of artists who have this title
    TitleBSTNode* left;                    // Pointer to the left child in the BST
    TitleBSTNode* right;                   // Pointer to the right child in the BST

public:
    // Default constructor: initializes an empty node
    TitleBSTNode() : count(0), left(nullptr), right(nullptr) {}

    // Parameterized constructor: creates a new node with artist, title, and running time
    TitleBSTNode(const std::string& art, const std::string& tit, int time_sec)
        : title(tit), count(1), left(nullptr), right(nullptr) {
        artist.push_back(art);             // Add artist name to the list
        rt.push_back(time_sec);            // Add runtime (in seconds)
        int m = time_sec / 60, s = time_sec % 60;       // Convert seconds to minutes and seconds
        std::stringstream ss;
        ss << m << ":" << (s < 10 ? "0" : "") << s;     // Format time as "m:ss"
        run_time = ss.str();              // Store formatted runtime string
    }

    // ===== Getter methods =====
    std::string getTitle() const { return title; }                          // Returns title name
    TitleBSTNode* getLeft() const { return left; }                          // Returns left child pointer
    TitleBSTNode* getRight() const { return right; }                        // Returns right child pointer
    const std::vector<std::string>& getArtists() const { return artist; }   // Returns artist list
    const std::vector<int>& getRunTimes() const { return rt; }              // Returns runtime list

    // ===== Setter methods =====
    void setLeft(TitleBSTNode* n) { left = n; }                             // Sets left child pointer
    void setRight(TitleBSTNode* n) { right = n; }                           // Sets right child pointer

    // Adds a new artist to this title node
    void addArtist(const std::string& art, int time_sec) {
        artist.push_back(art);               // Add new artist to list
        rt.push_back(time_sec);              // Add runtime in seconds
        count++;                             // Increment number of artists with same title
        int m = time_sec / 60, s = time_sec % 60;   // Convert time
        std::stringstream ss;
        ss << m << ":" << (s < 10 ? "0" : "") << s; // Format as "m:ss"
        run_time = ss.str();                 // Update runtime string
    }

    // Swaps all information with another node (used for deletion)
    void swapContent(TitleBSTNode* o) {
        title = o->title;
        artist = o->artist;
        rt = o->rt;
        run_time = o->run_time;
        count = o->count;
    }

    // Removes an artist entry by name (used when one artist’s song is deleted)
    bool removeArtist(const std::string& art) {
        for (size_t i = 0; i < artist.size(); ++i) {   // Loop through artist list
            if (artist[i] == art) {                    // Found target artist
                artist.erase(artist.begin() + i);      // Remove artist name
                rt.erase(rt.begin() + i);              // Remove corresponding runtime
                count--;                               // Decrease artist count
                return true;                           // Successfully removed
            }
        }
        return false;                                  // Artist not found
    }

    // Placeholder setup function for potential future use
    void set() {}

    // Placeholder search function for potential future use
    void search() {}
};