#pragma once
#include <string>

class PlayListNode {
private:
    std::string artist;        // Stores the artist's name
    std::string title;         // Stores the song title
    int runtime_sec;           // Stores the song's running time in seconds

    PlayListNode* prev;        // Pointer to the previous node in the circular list
    PlayListNode* next;        // Pointer to the next node in the circular list

public:
    // Default constructor: initializes an empty node
    PlayListNode() : runtime_sec(0), prev(nullptr), next(nullptr) {}

    // Parameterized constructor: initializes node with artist, title, and runtime
    PlayListNode(const std::string& art, const std::string& tit, int time_sec)
        : artist(art), title(tit), runtime_sec(time_sec), prev(nullptr), next(nullptr) {
    }

    // Destructor: cleans up node resources (no dynamic allocation used here)
    ~PlayListNode() {}

    // ===== Getter methods =====
    std::string getArtist() const { return artist; }          // Returns the artist name
    std::string getTitle() const { return title; }            // Returns the song title
    int getRunTimeSec() const { return runtime_sec; }         // Returns the running time (in seconds)

    PlayListNode* getPrev() const { return prev; }            // Returns the previous node pointer
    PlayListNode* getNext() const { return next; }            // Returns the next node pointer

    // ===== Setter methods =====
    void setPrev(PlayListNode* p) { prev = p; }               // Sets the previous node pointer
    void setNext(PlayListNode* n) { next = n; }               // Sets the next node pointer

    // Placeholder function (kept for skeleton consistency)
    void set() {}
};