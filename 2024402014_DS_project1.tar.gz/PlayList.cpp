#include "PlayList.h"
#include "ArtistBST.h" // for secondsToTimeStr()
#include <iostream>
#include <string>
#include <sstream>

using namespace std;

// Constructor: initializes an empty playlist
PlayList::PlayList() : head(nullptr), cursor(nullptr), count(0), time(0) {
    data = "";
}

// Destructor: deletes all nodes and resets playlist
PlayList::~PlayList() {
    if (empty()) return;                                // If already empty, nothing to delete

    PlayListNode* current = head;                       // Start from the head node
    PlayListNode* nextNode = nullptr;

    // Since it’s a circular list, stop once we loop back to head
    do {
        nextNode = current->getNext();                  // Store next node
        delete current;                                 // Delete current node
        current = nextNode;                             // Move forward
    } while (current != nullptr && current != head);     // Stop when back at head

    // Reset all fields
    head = nullptr;
    cursor = nullptr;
    count = 0;
    time = 0;
}

// Inserts a new song into the circular linked list
void PlayList::insert_node(const std::string& artist, const std::string& title, int time_sec) {
    PlayListNode* newNode = new PlayListNode(artist, title, time_sec); // Create new node

    if (empty()) {                                     // Case: list is empty
        head = newNode;                                // New node becomes head
        newNode->setNext(newNode);                     // Points to itself (circular)
        newNode->setPrev(newNode);
        cursor = head;                                 // Cursor points to head
    }
    else {                                             // Case: list already has nodes
        PlayListNode* tail = head->getPrev();          // Find tail (previous of head)
        tail->setNext(newNode);                        // Link tail to new node
        newNode->setPrev(tail);                        // Link new node back to tail
        newNode->setNext(head);                        // Link new node to head
        head->setPrev(newNode);                        // Update head’s previous pointer
    }

    count++;                                           // Increment song count
    time += time_sec;                                  // Add to total play time
}

// Deletes a song node by its title (deletes first match found)
void PlayList::delete_node(const std::string& title) {
    if (empty()) return;                               // No nodes to delete

    PlayListNode* current = head;                      // Start at head
    PlayListNode* prevNode = nullptr;

    do {
        if (current->getTitle() == title) {            // Match found
            time -= current->getRunTimeSec();          // Subtract runtime
            count--;                                   // Decrease song count

            // Case: only one node in the list
            if (current == head && current->getNext() == head) {
                delete current;
                head = nullptr;
                cursor = nullptr;
                return;
            }

            // Case: deleting head node
            if (current == head) {
                PlayListNode* tail = head->getPrev();  // Find tail
                head = head->getNext();                // Move head forward
                tail->setNext(head);                   // Update tail’s next pointer
                head->setPrev(tail);                   // Update head’s previous pointer
            }
            else {                                     // Case: deleting middle or tail node
                current->getPrev()->setNext(current->getNext());
                current->getNext()->setPrev(current->getPrev());
            }

            if (current == cursor) cursor = head;      // Reset cursor if deleted node was current
            delete current;                            // Delete the node
            return;
        }

        prevNode = current;                            // Move to next node
        current = current->getNext();
    } while (current != head);                         // Stop when looped back to start
}

/* ===========================
   Overload: delete by (artist, title)
   - Deletes a song only if both artist and title match
   - Returns true if deletion succeeded, false otherwise
   =========================== */
bool PlayList::delete_node(const std::string& artist, const std::string& title) {
    if (this->empty()) return false;                   // If list is empty, nothing to delete

    PlayListNode* cur = this->head;

    // Traverse one full cycle through circular list
    do {
        if (cur->getArtist() == artist && cur->getTitle() == title) { // Exact match
            this->time -= cur->getRunTimeSec();        // Subtract from total time
            this->count -= 1;                          // Decrease song count

            // Case: only one node in list
            if (cur == this->head && cur->getNext() == this->head) {
                delete cur;
                this->head = nullptr;
                this->cursor = nullptr;
                return true;
            }

            // Case: deleting head node
            if (cur == this->head) {
                PlayListNode* tail = this->head->getPrev();
                this->head = this->head->getNext();
                tail->setNext(this->head);
                this->head->setPrev(tail);
            }
            else {                                     // Case: deleting middle or tail node
                cur->getPrev()->setNext(cur->getNext());
                cur->getNext()->setPrev(cur->getPrev());
            }

            if (cur == this->cursor) this->cursor = this->head; // Move cursor to head if deleted
            delete cur;
            return true;                            // Deletion successful
        }
        cur = cur->getNext();                          // Move to next node
    } while (cur != this->head);

    return false;                                      // Song not found
}

// Checks whether the playlist is empty
bool PlayList::empty() { return head == nullptr; }

// Checks whether the playlist is full (maximum 10 songs)
bool PlayList::full() { return count >= 10; }

// Returns true if playlist contains at least one song
bool PlayList::exist() { return count > 0; }

// Prints playlist contents in formatted style
string PlayList::print() {
    stringstream ss;

    if (empty()) {                                    // If list is empty → print error
        ss << "========ERROR========\n";
        ss << "600\n";
        ss << "=====================\n";
        return ss.str();
    }

    ss << "========PRINT========\n";
    ss << "PlayList\n";

    PlayListNode* current = head;
    int loopTime = 0;

    // Traverse the circular list and print each song
    do {
        ss << current->getArtist() << "/" << current->getTitle() << "/"
            << secondsToTimeStr(current->getRunTimeSec()) << "\n"; // Format: Artist/Title/Time
        loopTime += current->getRunTimeSec();
        current = current->getNext();
    } while (current != head);

    // Convert total seconds to minutes and seconds
    int minutes = time / 60;
    int seconds = time % 60;

    ss << "Count : " << count << " / 10\n";           // Print total number of songs
    ss << "Time : " << minutes << "min " << seconds << "sec\n"; // Print total runtime
    ss << "=====================\n";

    return ss.str();                                  // Return formatted playlist info
}

// Returns total playlist runtime in seconds
int PlayList::run_time() { return time; }